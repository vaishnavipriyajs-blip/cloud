
from flask import Flask, render_template, request
import dropbox
import os

app = Flask(__name__, template_folder=".")

TOKEN = os.environ.get("DROPBOX_TOKEN")
dbx = dropbox.Dropbox(TOKEN)


# Display the webpage
@app.route("/")
def home():
    return render_template("index.html")


# Upload a user-selected file
@app.route("/upload", methods=["POST"])
def upload():
    file = request.files["file"]

    dbx.files_upload(
        file.read(),
        "/" + file.filename,
        mode=dropbox.files.WriteMode.overwrite
    )

    return "File uploaded successfully to Dropbox!"


# Download a file from Dropbox
@app.route("/download")
def download():
    metadata, response = dbx.files_download("/sample.txt")

    with open("downloaded_sample.txt", "wb") as f:
        f.write(response.content)

    return "File downloaded successfully!"


if __name__ == "__main__":
    app.run(debug=True)