
const express = require('express');
const app = express();

app.use(express.json());

let books = [
    { id: 1, title: "Harry Potter" },
    { id: 2, title: "Twilight" }
];

// GET - Display all books
app.get('/api/books', (req, res) => {
    res.send(books);
});

// GET - Display one book
app.get('/api/books/:id', (req, res) => {
    let book = books.find(b => b.id == req.params.id);

    if (!book) {
        return res.status(404).send("Book not found");
    }

    res.send(book);
});

// POST - Add a book
app.post('/api/books', (req, res) => {
    let book = {
        id: books.length ? Math.max(...books.map(b => b.id)) + 1 : 1,
        title: req.body.title
    };

    books.push(book);
    res.status(201).send("Book added successfully");
});

// PUT - Update a book
app.put('/api/books/:id', (req, res) => {
    let book = books.find(b => b.id == req.params.id);

    if (!book) {
        return res.status(404).send("Book not found");
    }

    book.title = req.body.title;
    Object.assign(book,req.body);
    res.send("Book updated successfully");
});

// DELETE - Delete a book
app.delete('/api/books/:id', (req, res) => {
    let oldLength = books.length;

    books = books.filter(b => b.id != req.params.id);

    if (books.length === oldLength) {
        return res.status(404).send("Book not found");
    }

    res.send("Book deleted successfully");
});

// Start server
app.listen(8080, () => {
    console.log("Server running on port 8080");
});