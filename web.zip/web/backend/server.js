
const dns = require("dns");

// Set DNS servers
dns.setServers(["8.8.8.8", "8.8.4.4"]);

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb+srv://vaishu:1234567vaishu@cluster0.yizggid.mongodb.net/details?appName=Cluster0")
    .then(() => console.log("MongoDB connected"))
    .catch(err => console.log(err));

const Student = mongoose.model("Student", {
    name: String,
    email: String,
    department: String,
    gender: String,
    skills: [String]
},"vaishu");

// Display
app.get("/students", async (req, res) => {
    res.json(await Student.find());
});

// Register
app.post("/students", async (req, res) => {
    res.json(await Student.create(req.body));
});

// Update
app.put("/students/:id", async (req, res) => {
    res.json(await Student.findByIdAndUpdate(
        req.params.id, req.body, { new: true }
    ));
});

// Delete
app.delete("/students/:id", async (req, res) => {
    await Student.findByIdAndDelete(req.params.id);
    res.send("Deleted");
});

app.listen(5000, () => console.log("Server running"));
