
import { useState } from "react";
import { auth, provider, db } from "./firebase";

import {
  signInWithPopup,
  signOut
} from "firebase/auth";

import {
  doc,
  getDoc,
  setDoc,
  collection,
  addDoc,
  serverTimestamp
} from "firebase/firestore";

function App() {
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState("");

  // Google login
  const login = async () => {
    try {
      const result = await signInWithPopup(auth, provider);
      const loggedInUser = result.user;

      setUser(loggedInUser);

      // Save user details
      await setDoc(
        doc(db, "users", loggedInUser.uid),
        {
          name: loggedInUser.displayName,
          email: loggedInUser.email,
          photoURL: loggedInUser.photoURL
        },
        { merge: true }
      );
    } catch (error) {
      alert(error.message);
    }
  };

  // Save dashboard text
  const saveMessage = async () => {
    if (!message.trim()) {
      setStatus("Please enter some text!");
      return;
    }

    try {
      await addDoc(collection(db, "messages"), {
        text: message,
        owner: user.uid,
        createdAt: serverTimestamp()
      });

      setMessage("");
      setStatus("Message saved successfully!");
    } catch (error) {
      setStatus("Error: " + error.message);
    }
  };

  // Google logout
  const logout = async () => {
    await signOut(auth);
    setUser(null);
    setStatus("");
  };

  return (
    <div style={{
      textAlign: "center",
      fontFamily: "Arial",
      margin: "60px auto",
      maxWidth: "500px"
    }}>
      {!user ? (
        <>
          <h1>Login Page</h1>
          <p>Sign in to access your dashboard.</p>
          <button onClick={login}>
            Sign in with Google
          </button>
        </>
      ) : (
        <>
          <h1>Welcome Dashboard</h1>

          {user.photoURL && (
            <img
              src={user.photoURL}
              alt="Profile"
              width="80"
              style={{ borderRadius: "50%" }}
            />
          )}

          <h2>Hello, {user.displayName}!</h2>
          <p>{user.email}</p>

          <hr />

          <h3>Save Your Message</h3>

          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Enter something..."
            style={{ padding: "10px", width: "65%" }}
          />

          <button onClick={saveMessage}>
            Save
          </button>

          <p>{status}</p>

          <button onClick={logout}>
            Sign Out
          </button>
        </>
      )}
    </div>
  );
}

export default App;