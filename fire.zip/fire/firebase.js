// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDuFsxdbYmkACZKG-V_yuYFuDkgj7rqcEI",
  authDomain: "fir-auth-lab-c95e5.firebaseapp.com",
  projectId: "fir-auth-lab-c95e5",
  storageBucket: "fir-auth-lab-c95e5.firebasestorage.app",
  messagingSenderId: "644695658649",
  appId: "1:644695658649:web:7facf1d8d0a685220de808",
  measurementId: "G-2T7LB0XQDS"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const provider = new GoogleAuthProvider();
export const db = getFirestore(app);